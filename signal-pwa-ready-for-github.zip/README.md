# Signal — AI Motion Experiment

## Deploy
1. Create a new GitHub repository.
2. Upload everything in this folder to the repository root.
3. In Netlify choose **Add new project → Import an existing project**.
4. Choose GitHub and select the repository.
5. No build command is required.
6. Publish directory can be left as the repository root (`.`).
7. Publish.

After that, every push to the main branch will redeploy automatically.

## Install on phone

### iPhone
Open the Netlify URL in Safari → Share → **Add to Home Screen** → Add.

### Android
Open the Netlify URL in Chrome. Use the browser menu and choose **Install app** or **Add to Home screen** when offered.

The app is configured for standalone portrait mode and includes an offline cache.
